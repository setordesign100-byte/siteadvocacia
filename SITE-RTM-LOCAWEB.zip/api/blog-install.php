<?php
declare(strict_types=1);
return ['primary_account' => ['username' => 'admin.rtm', 'passwordHash' => '$2y$12$yrFXzrd8iHQpdmIhCoyAqOtjUMijGSsAxa2mID5qKDyX5yYndvwCe', 'provisioningId' => '34ecdb92c33fdd84d89ce4626c5ab6f4']];

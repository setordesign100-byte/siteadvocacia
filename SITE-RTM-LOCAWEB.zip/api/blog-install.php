<?php
declare(strict_types=1);
return ['activation_hash' => '9a6d1e2c6e12bfe8109bd8e78436392fd703a820f7181c3209fa7d146f7f57a7'];
